module.exports =
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 66008:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



const AWS = __webpack_require__(23480);

const cloudformation = new AWS.CloudFormation();

const {
  execSync
} = __webpack_require__(63129);

const default_region = process.env.AWS_REGION || 'eu-west-1';

const {
  emptyBucket
} = __webpack_require__(44360);

const deploySucceeded = id => {
  console.log(`Deploy succeed. Id ${id}`);
};

const deployFailed = (res, id) => {
  console.log(`Deploy deployFailed. Id ${id}`);
  console.log(`Reason: ${res}`);
};

const destroySucceeded = id => {
  console.log(`Destroy succeeded. id: ${id}`);
};

const destroyFailed = (res, id) => {
  console.log(`Destroy failed: ${id}`);
  console.log(`Reason: ${res}`);
};

module.exports.deploy = async id => {
  console.log(`Deploy stack ${id}`);
  console.log(id);
  let res;

  try {
    res = await deployCDK({
      id: id,
      command: 'deploy',
      additionalCommandParam: ''
    });
  } catch (e) {
    deployFailed("Failed to deploy CDK" + e, id);
  }

  console.log('Deploy returned');
  console.log(res); // CDK deploy finished/failed

  if (isResultReturnCloudformationArn(res)) {
    const stackName = res.split('/')[1];
    console.log(`Deploy succeeded, stack name - ${stackName}`);
    deploySucceeded(id);
  } else {
    console.log('Deploy failed - return result is not stack arn');
    deployFailed(res, id);
  }
};

module.exports.destroy = async id => {
  console.log(`Destroy stack ${id}`); // empty buckets so that CDK destroy can delete it

  const siteBucketName = await getOutputFromStack(id, 'bucketName');
  await emptyBucket(siteBucketName);
  const res = await deployCDK({
    id: id,
    awsRegion: default_region,
    command: 'destroy',
    additionalCommandParam: '--force'
  });
  console.log('Destroy returned');
  console.log(res);

  if (res === "") {
    await destroySucceeded(id);
  } else {
    await destroyFailed(res, id);
  }
};

const isResultReturnCloudformationArn = res => {
  const regex = new RegExp('^arn:aws:cloudformation:' + default_region + ':.+:stack\\/.*\\/.*', 'gi');
  return regex.test(res);
};

const getOutputFromStack = async (stackId, outputKey) => {
  return new Promise((resolve, reject) => {
    try {
      const params = {
        StackName: stackId
      };
      cloudformation.describeStacks(params, function (err, data) {
        if (err) {
          console.log(err, err.stack);
          reject();
        } else {
          console.log(data);
          console.log(data.Stacks[0].Outputs);
          resolve(data.Stacks[0].Outputs.find(stackOutput => stackOutput.OutputKey === outputKey).OutputValue);
        }
      });
    } catch (e) {
      console.log(e);
      reject();
    }
  });
};

const deployCDK = async params => {
  console.log(`Stack request for: ${params.id}`);
  console.log('Request started'); // Set process.env.HOME Lambda default HOME is /home/usrXXX.

  const cmd = `
  export HOME='/tmp'
  ID_ENV='${params.id}' /opt/nodejs/node_modules/aws-cdk/bin/cdk ${params.command} -v ${params.additionalCommandParam}
  `;
  console.log(cmd);
  return execSync(cmd).toString();
};

/***/ }),

/***/ 93497:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



const {
  deploy,
  destroy
} = __webpack_require__(66008); // might need to run "cdk bootstrap --profile <profile_if_you_use> aws://<accountId>/<AWS_REGION>" in the acc/region when setting up for the first time


exports.deploy = async event => {
  console.log(event);
  await deploy(event['id']);
};

exports.destroy = async event => {
  console.log(event);
  await destroy(event['id']);
};

/***/ }),

/***/ 44360:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "emptyBucket": () => /* binding */ emptyBucket
/* harmony export */ });
const AWS = __webpack_require__(23480);

const s3 = new AWS.S3();
const emptyBucket = async bucketName => {
  // delete bucket contents
  const listedObjects = await s3.listObjectVersions({
    Bucket: bucketName
  }).promise(); // nothing left - we're done!

  const contents = (listedObjects.Versions || []).concat(listedObjects.DeleteMarkers || []);
  if (contents.length === 0) return;
  let records = []; // make a list of objects to delete

  for (let record of contents) {
    records.push({
      Key: record.Key,
      VersionId: record.VersionId
    });
  }

  await s3.deleteObjects({
    Bucket: bucketName,
    Delete: {
      Objects: records
    }
  }).promise(); // repeat as necessary

  if (listedObjects.IsTruncated) await emptyBucket(bucketName);
};

/***/ }),

/***/ 23480:
/***/ ((module) => {

module.exports = require("aws-sdk");;

/***/ }),

/***/ 63129:
/***/ ((module) => {

module.exports = require("child_process");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop)
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	// module exports must be returned from runtime so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(93497);
/******/ })()
;